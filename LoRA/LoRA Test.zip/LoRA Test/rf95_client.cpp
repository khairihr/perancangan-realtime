// rf95_client.cpp
//
// Example program showing how to use RH_RF95 on Raspberry Pi
// Uses the pigpio library to access the GPIO pins to drive the RFM95 module

#include <pigpio.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include <RH_RF69.h>
#include <RH_RF95.h>

#define BOARD_LORASPI

#include "../RasPiBoards.h"

// Our RFM95 Configuration 
#define RF_FREQUENCY  915.00
//#define RF_NODE_ID    1

// Create an instance of a driver
RH_RF95 rf95(RF_CS_PIN, RF_IRQ_PIN);
//RH_RF95 rf95(RF_CS_PIN);

//Flag for Ctrl-C
volatile sig_atomic_t force_exit = false;

void sig_handler(int sig)
{
  printf("\n%s Break received, exiting!\n", __BASEFILE__);
  force_exit=true;
}

//Main Function
int main (int argc, const char* argv[] )
{
  unsigned long led_blink = 0;
  
  signal(SIGINT, sig_handler);
  printf( "%s\n", __BASEFILE__);

  if (gpioInitialise() < 0) {
    fprintf(stderr, "%s pigpio initialization failed\n\n", __BASEFILE__);
    return 1;
  }
  
  printf( "RF95 CS=GPIO%d", RF_CS_PIN);

#ifdef RF_LED_PIN
  gpioSetMode(RF_LED_PIN, PI_OUTPUT);
  gpioWrite(RF_LED_PIN, PI_ON);
#endif

#ifdef RF_IRQ_PIN
  printf( ", IRQ=GPIO%d", RF_IRQ_PIN );
  // IRQ Pin input/pull down
  gpioSetMode(RF_IRQ_PIN, PI_INPUT);
  gpioSetPullUpDown(RF_IRQ_PIN, PI_PUD_DOWN);
  // Now we can enable Rising edge detection
  gpioSetAlertFunc(RF_IRQ_PIN, NULL);  // Use a callback here if necessary
#endif
  
#ifdef RF_RST_PIN
  printf( ", RST=GPIO%d", RF_RST_PIN );
  // Pulse a reset on module
  gpioSetMode(RF_RST_PIN, PI_OUTPUT);
  gpioWrite(RF_RST_PIN, PI_OFF);
  gpioDelay(150 * 1000); // 150 ms
  gpioWrite(RF_RST_PIN, PI_ON);
  gpioDelay(100 * 1000); // 100 ms
#endif

#ifdef RF_LED_PIN
  printf( ", LED=GPIO%d", RF_LED_PIN );
  gpioWrite(RF_LED_PIN, PI_OFF);
#endif

  if (!rf95.init()) {
    fprintf(stderr, "\nRF95 module init failed, Please verify wiring/module\n");
  } else {
    rf95.setTxPower(14, false);
    rf95.setFrequency(RF_FREQUENCY);
    rf95.setPromiscuous(true);
    rf95.setModeRx();
    printf("Listening packet...\n");

    while (!force_exit) {
        uint8_t data[] = "Hi Raspi!";
        uint8_t lena = sizeof(data);
        printf("Sending to rf95_client");
        printf("\n");
        rf95.send(data, lena);
        rf95.waitPacketSent();
        gpioDelay(400 * 1000); // 400 ms
    }
  }

#ifdef RF_LED_PIN
  gpioWrite(RF_LED_PIN, PI_OFF);
#endif
  printf("\n%s Ending\n", __BASEFILE__);
  gpioTerminate();
  return 0;
}
